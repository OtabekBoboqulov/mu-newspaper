<?php
    use Illuminate\Support\Facades\Auth;
?>
<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto px-4">
        <div class="flex flex-col lg:flex-row justify-between items-start space-y-6 lg:space-y-0 lg:space-x-6">
            <!-- Author Profile Image -->
            <a href="../authors/<?php echo e($post->author->id); ?>" class="lg:w-1/4 flex justify-center lg:justify-start mt-10">
                <img src="<?php echo e(asset($post->author->profile_image_url)); ?>" alt="<?php echo e($post->author->first_name); ?>"
                     class="w-48 h-48 lg:w-64 lg:h-64 rounded-full object-cover">
            </a>
            <!-- Post Content -->
            <div class="lg:w-3/4 post-body max-w-full break-words whitespace-normal">
                <h2 class="text-3xl font-bold my-6"><?php echo e($post->title); ?></h2>
                <p class="mb-4"><?php echo $post->body; ?></p>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin', Auth::user())): ?>
                    <form action="/posts/<?php echo e($post->id); ?>/publish" method="post" class="mb-5">
                        <?php echo csrf_field(); ?>
                        <?php if(!$post->published): ?>
                            <button class="mt-2 bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600">
                                Publish
                            </button>
                        <?php else: ?>
                            <button class="mt-2 bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600">
                                Remove
                            </button>
                        <?php endif; ?>
                    </form>
                    <form action="/posts/<?php echo e($post->id); ?>" method="post" class="mb-5">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="mt-2 bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600">
                            Delete
                        </button>
                    </form>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $post)): ?>
                    <div class="mb-5">
                        <a href="/posts/<?php echo e($post->id); ?>/edit"
                           class="mt-2 bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">Edit post</a>
                    </div>
                <?php endif; ?>
                <p class="text-gray-600 text-sm">By <a href="../authors/<?php echo e($post->author->id); ?>"
                                                       class="text-blue-500 hover:underline"><?php echo e($post->author->username); ?></a>
                    on <?php echo e($post->created_at->format('j F Y')); ?></p>

                <!-- Like Button -->
                <div class="mt-6 flex items-center">
                    <?php if(auth()->guard()->check()): ?>
                        <button id="likeButton"
                                class="flex items-center p-4 rounded-full
                                   <?php echo e($post->likes->contains('user_id', Auth::id()) ? 'bg-red-500 text-white' : 'bg-gray-300 text-gray-700'); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                 class="bi bi-heart" viewBox="0 0 16 16">
                                <path
                                    d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143q.09.083.176.171a3 3 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15"/>
                            </svg>
                        </button>
                    <?php else: ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                             class="bi bi-heart" viewBox="0 0 16 16">
                            <path
                                d="m8 2.748-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143q.09.083.176.171a3 3 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15"/>
                        </svg>
                    <?php endif; ?>
                    <span id="likeCount" class="ml-2"><?php echo e(count($post->likes)); ?></span>
                </div>

                <!-- Comment Section -->
                <div class="mt-8">
                    <h3 class="text-xl font-semibold mb-4">Comments (<?php echo e(count($post->comments)); ?>)</h3>
                    <?php if(auth()->guard()->check()): ?>
                        <form action="/posts/<?php echo e($post->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e(Auth::id()); ?>">
                            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                            <textarea class="w-full p-4 border rounded-md" placeholder="Add a comment..."
                                      name="comment"></textarea>
                            <button class="mt-2 bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600">
                                Submit
                            </button>
                        </form>
                    <?php else: ?>
                        <span><a href="/login" class="text-blue-600">Log In</a> to leave a comment</span>
                    <?php endif; ?>
                    <?php $__currentLoopData = $post->comments->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if (isset($component)) { $__componentOriginalfe4855bb643954c83a0cbd6710da1102 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfe4855bb643954c83a0cbd6710da1102 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.comment','data' => ['comment' => $comment]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('comment'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['comment' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($comment)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfe4855bb643954c83a0cbd6710da1102)): ?>
<?php $attributes = $__attributesOriginalfe4855bb643954c83a0cbd6710da1102; ?>
<?php unset($__attributesOriginalfe4855bb643954c83a0cbd6710da1102); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfe4855bb643954c83a0cbd6710da1102)): ?>
<?php $component = $__componentOriginalfe4855bb643954c83a0cbd6710da1102; ?>
<?php unset($__componentOriginalfe4855bb643954c83a0cbd6710da1102); ?>
<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
    <script>
        const likeButton = document.getElementById('likeButton');
        const likeCount = document.getElementById('likeCount');

        likeButton.addEventListener('click', () => {
            const postId = <?php echo e($post->id); ?>;
            fetch(`/posts/${postId}/like`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                },
                body: JSON.stringify({})
            })
                .then(response => response.json())
                .then(data => {
                    likeButton.classList.toggle('bg-red-500', data.liked);
                    likeButton.classList.toggle('text-white', data.liked);
                    likeButton.classList.toggle('bg-gray-300', !data.liked);
                    likeButton.classList.toggle('text-gray-700', !data.liked);
                    likeCount.textContent = data.likes_count;
                })
                .catch(error => console.error('Error:', error));
        });

    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mu-newspaper\resources\views/posts/show.blade.php ENDPATH**/ ?>