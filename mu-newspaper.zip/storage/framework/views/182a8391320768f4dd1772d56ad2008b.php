<?php if (isset($component)) { $__componentOriginal9a63433ba02f3bc846ebb75c8b48bf06 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9a63433ba02f3bc846ebb75c8b48bf06 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.post-form','data' => ['heading' => 'Create a Post']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('post-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['heading' => 'Create a Post']); ?>
    <form action="/posts" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-4">
            <label for="title" class="block text-gray-700 font-semibold">Title</label>
            <input type="text" id="title" name="title"
                   class="w-full mt-2 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                   placeholder="Enter the title of your post">
        </div>
        <div class="mb-6">
            <label for="body" class="block text-gray-700 font-semibold">Body</label>
            <textarea id="body" name="body" rows="10"
                      class="w-full mt-2 p-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Write your post here..."></textarea>
        </div>
        <button type="submit" class="w-full bg-blue-500 text-white py-3 px-4 rounded-lg hover:bg-blue-700">Publish
            Post
        </button>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9a63433ba02f3bc846ebb75c8b48bf06)): ?>
<?php $attributes = $__attributesOriginal9a63433ba02f3bc846ebb75c8b48bf06; ?>
<?php unset($__attributesOriginal9a63433ba02f3bc846ebb75c8b48bf06); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9a63433ba02f3bc846ebb75c8b48bf06)): ?>
<?php $component = $__componentOriginal9a63433ba02f3bc846ebb75c8b48bf06; ?>
<?php unset($__componentOriginal9a63433ba02f3bc846ebb75c8b48bf06); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mu-newspaper\resources\views/posts/create.blade.php ENDPATH**/ ?>