<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title'=>'Sign Up']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title'=>'Sign Up']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($title); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <!-- Standard favicon -->
    <link rel="icon" href="<?php echo e(asset('favicon.png')); ?>" type="image/x-icon">

    <!-- Apple Touch Icon (for iOS) -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon.png')); ?>" sizes="180x180">

    <!-- Android Icon -->
    <link rel="icon" href="<?php echo e(asset('favicon.png')); ?>" sizes="192x192" type="image/png">
</head>
<body class="bg-gray-100">
<div class="flex items-center justify-center min-h-screen py-12">
    <div class="bg-white p-8 rounded-lg shadow-md w-full max-w-md">
        <?php if (isset($component)) { $__componentOriginal84ae00d9b48589919d95b7b14ece23ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84ae00d9b48589919d95b7b14ece23ad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-to-home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-to-home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84ae00d9b48589919d95b7b14ece23ad)): ?>
<?php $attributes = $__attributesOriginal84ae00d9b48589919d95b7b14ece23ad; ?>
<?php unset($__attributesOriginal84ae00d9b48589919d95b7b14ece23ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84ae00d9b48589919d95b7b14ece23ad)): ?>
<?php $component = $__componentOriginal84ae00d9b48589919d95b7b14ece23ad; ?>
<?php unset($__componentOriginal84ae00d9b48589919d95b7b14ece23ad); ?>
<?php endif; ?>
        <?php echo e($slot); ?>

    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\mu-newspaper\resources\views/components/auth-layout.blade.php ENDPATH**/ ?>