<?php use Illuminate\Support\Facades\Auth; ?>
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['author'=>null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['author'=>null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!-- Author 1 -->
<div class="text-center">
    <img src="<?php echo e(asset($author->profile_image_url)); ?>" alt="Author 1" class="w-32 h-32 rounded-full mx-auto mb-4">
    <h2 class="text-xl font-semibold text-gray-800"><?php echo e($author->username); ?></h2>
    <a href="/authors/<?php echo e($author->id); ?>" class="text-blue-600 hover:underline">Posts: <?php echo e(count($author->posts)); ?></a>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('superadmin', Auth::user())): ?>
        <br>
        <?php if($author->status != 'superadmin' && $author->status != 'admin'): ?>
            <a href="/promotion/<?php echo e($author->id); ?>" class="text-blue-600 hover:underline">Promote to Admin</a>
        <?php elseif($author->status == 'admin' && $author->status != 'superadmin'): ?>
            <a href="/removeadmin/<?php echo e($author->id); ?>" class="text-blue-600 hover:underline">Remove Admin</a>
        <?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\mu-newspaper\resources\views/components/author.blade.php ENDPATH**/ ?>