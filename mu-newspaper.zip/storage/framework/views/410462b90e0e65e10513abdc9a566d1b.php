<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MU Newspaper - Welcome</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <!-- Standard favicon -->
    <link rel="icon" href="<?php echo e(asset('favicon.png')); ?>" type="image/x-icon">

    <!-- Apple Touch Icon (for iOS) -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon.png')); ?>" sizes="180x180">

    <!-- Android Icon -->
    <link rel="icon" href="<?php echo e(asset('favicon.png')); ?>" sizes="192x192" type="image/png">
</head>
<body class="bg-gray-100">

<!-- Banner Section -->
<header class="bg-blue-600 text-white">
    <div class="container mx-auto flex flex-col items-center py-20">
        <h1 class="text-5xl font-bold mb-4">Welcome to MU Newspaper</h1>
        <p class="text-xl mb-8">Your daily source for the latest news and stories.</p>
        <div class="flex space-x-4">
            <?php if(auth()->guard()->guest()): ?>
                <a href="/login" class="bg-white text-blue-600 px-6 py-2 rounded hover:bg-gray-100">Log In</a>
                <a href="/signup" class="bg-blue-500 px-6 py-2 rounded hover:bg-blue-700">Sign Up</a>
            <?php else: ?>
                <a href="/posts" class="bg-blue-500 px-6 py-2 rounded hover:bg-blue-700">View Posts</a>
                <form action="/logout" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="bg-white text-blue-600 px-6 py-2 rounded hover:bg-gray-100">
                        Log Out
                    </button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</header>

<!-- Posts Section -->
<section class="container mx-auto py-20">
    <div class="text-center mb-12">
        <h2 class="text-4xl font-bold">Popular Posts</h2>
    </div>
    <div class="flex flex-wrap -mx-4">
        <!-- Example of a Post Card -->
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-full md:w-1/2 lg:w-1/3 p-4">
                <div class="bg-white shadow-md rounded-lg overflow-hidden">
                    <div class="p-4 post-body max-w-full break-words whitespace-normal w-3/4">
                        <div class="flex items-center mb-4">
                            <img src="<?php echo e($post->author->profile_image_url); ?>" alt="Author Image"
                                 class="w-10 h-10 rounded-full mr-4">
                            <div>
                                <h3 class="text-lg font-bold"><?php echo e($post->author->name); ?></h3>
                                <p class="text-gray-600 text-sm"><?php echo e($post->created_at->format('j F Y')); ?></p>
                            </div>
                        </div>
                        <p class="text-gray-700"><?php echo Str::limit($post->body, 100); ?></p>
                        <a href="/posts/<?php echo e($post->id); ?>" class="text-blue-500 mt-2 block">Read more...</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- See More Button -->
    <div class="text-center mt-8">
        <a href="/posts" class="bg-blue-500 text-white px-6 py-3 rounded hover:bg-blue-700">See More</a>
    </div>
</section>


<!-- Features Section -->
<section class="container mx-auto py-20">
    <div class="text-center mb-12">
        <h2 class="text-4xl font-bold">Why Choose MU Newspaper?</h2>
        <p class="text-gray-600 mt-4">Discover our unique features and offerings.</p>
    </div>
    <div class="flex flex-wrap justify-center">
        <div class="w-full md:w-1/3 p-4">
            <div class="bg-white shadow-md p-6 rounded-lg text-center">
                <h3 class="text-2xl font-bold mb-4">Fresh Content</h3>
                <p class="text-gray-600">Stay updated with the latest news and articles from MU students.</p>
            </div>
        </div>
        <div class="w-full md:w-1/3 p-4">
            <div class="bg-white shadow-md p-6 rounded-lg text-center">
                <h3 class="text-2xl font-bold mb-4">Community Driven</h3>
                <p class="text-gray-600">Join our community of writers and share your own stories.</p>
            </div>
        </div>
        <div class="w-full md:w-1/3 p-4">
            <div class="bg-white shadow-md p-6 rounded-lg text-center">
                <h3 class="text-2xl font-bold mb-4">User Friendly</h3>
                <p class="text-gray-600">Enjoy a seamless and intuitive experience on our platform.</p>
            </div>
        </div>
    </div>
</section>

<!-- Call to Action Section -->
<?php if(auth()->guard()->guest()): ?>
    <section class="bg-gray-200 py-20">
        <div class="container mx-auto text-center">
            <h2 class="text-4xl font-bold mb-6">Start Your Journey with Us!</h2>
            <p class="text-gray-700 mb-8">Become a part of our growing community and share your stories today.</p>
            <a href="/signup" class="bg-blue-500 text-white px-8 py-3 rounded hover:bg-blue-700">Join Now</a>
        </div>
    </section>
<?php endif; ?>
<!-- Footer -->
<footer class="bg-gray-800 text-white py-6">
    <div class="container mx-auto text-center">
        <p>&copy; 2025 MU Newspaper. All rights reserved.</p>
        <div class="mt-4 space-x-4">
            <?php if (isset($component)) { $__componentOriginal677f03edb23dff14f06cecc48b460030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal677f03edb23dff14f06cecc48b460030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-link','data' => ['href' => 'https://t.me/millatumidiuni']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => 'https://t.me/millatumidiuni']); ?>Telegram <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $attributes = $__attributesOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__attributesOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $component = $__componentOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__componentOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal677f03edb23dff14f06cecc48b460030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal677f03edb23dff14f06cecc48b460030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-link','data' => ['href' => 'https://www.instagram.com/millatumidi_university']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => 'https://www.instagram.com/millatumidi_university']); ?>Instagram <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $attributes = $__attributesOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__attributesOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $component = $__componentOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__componentOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal677f03edb23dff14f06cecc48b460030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal677f03edb23dff14f06cecc48b460030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-link','data' => ['href' => 'https://www.youtube.com/@MillatUmidi']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => 'https://www.youtube.com/@MillatUmidi']); ?>YouTube <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $attributes = $__attributesOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__attributesOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $component = $__componentOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__componentOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal677f03edb23dff14f06cecc48b460030 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal677f03edb23dff14f06cecc48b460030 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer-link','data' => ['href' => 'https://millatumidi.uz/']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => 'https://millatumidi.uz/']); ?>MU site <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $attributes = $__attributesOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__attributesOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal677f03edb23dff14f06cecc48b460030)): ?>
<?php $component = $__componentOriginal677f03edb23dff14f06cecc48b460030; ?>
<?php unset($__componentOriginal677f03edb23dff14f06cecc48b460030); ?>
<?php endif; ?>
        </div>
    </div>
</footer>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\mu-newspaper\resources\views/welcome.blade.php ENDPATH**/ ?>