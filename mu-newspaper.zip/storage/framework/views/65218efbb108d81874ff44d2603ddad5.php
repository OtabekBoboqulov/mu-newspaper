<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['heading' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['heading' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create a Post</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <!-- Standard favicon -->
    <link rel="icon" href="<?php echo e(asset('favicon.png')); ?>" type="image/x-icon">

    <!-- Apple Touch Icon (for iOS) -->
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon.png')); ?>" sizes="180x180">

    <!-- Android Icon -->
    <link rel="icon" href="<?php echo e(asset('favicon.png')); ?>" sizes="192x192" type="image/png">
    <script src="https://cdn.ckeditor.com/ckeditor5/34.0.0/classic/ckeditor.js"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
<div class="bg-white rounded-lg shadow-lg p-8 max-w-lg w-full">
    <?php if (isset($component)) { $__componentOriginal84ae00d9b48589919d95b7b14ece23ad = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84ae00d9b48589919d95b7b14ece23ad = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-to-home','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-to-home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84ae00d9b48589919d95b7b14ece23ad)): ?>
<?php $attributes = $__attributesOriginal84ae00d9b48589919d95b7b14ece23ad; ?>
<?php unset($__attributesOriginal84ae00d9b48589919d95b7b14ece23ad); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84ae00d9b48589919d95b7b14ece23ad)): ?>
<?php $component = $__componentOriginal84ae00d9b48589919d95b7b14ece23ad; ?>
<?php unset($__componentOriginal84ae00d9b48589919d95b7b14ece23ad); ?>
<?php endif; ?>
    <h1 class="text-2xl font-bold text-gray-800 mb-6"><?php echo e($heading); ?></h1>
    <?php echo e($slot); ?>

</div>
<script>
    ClassicEditor
        .create(document.querySelector('#body'))
        .catch(error => {
            console.error(error);
        });
</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\mu-newspaper\resources\views/components/post-form.blade.php ENDPATH**/ ?>