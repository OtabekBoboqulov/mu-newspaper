<input {{ $attributes->merge(['class'=>"w-full p-2 border rounded-md", 'type'=>'text']) }} required>
