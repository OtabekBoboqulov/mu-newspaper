<a {{ $attributes->merge(['target'=>'_blank', 'class'=>"hover:text-blue-400"]) }}>{{ $slot }}</a>
