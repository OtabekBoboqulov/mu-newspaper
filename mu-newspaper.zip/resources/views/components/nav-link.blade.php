<li><a {{ $attributes->merge(['class'=>"hover:text-blue-500"]) }}>{{ $slot }}</a></li>
