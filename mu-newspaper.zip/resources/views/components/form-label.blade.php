<label {{ $attributes->merge(['class'=>"block text-gray-700"]) }}>{{ $slot }}</label>
